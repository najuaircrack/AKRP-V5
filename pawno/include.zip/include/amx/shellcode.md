amx_assembly shellcode
==========================================
AMX Assembly Library: Execute arbitrary x86 assembly.
------------------------------------------



## Functions


### `RunShellcode`:


#### Syntax


```pawn
RunShellcode(code_ptr, align)
```


#### Parameters


| 	**Name**	 | 	**Info**	 |
|	---	|	---	|
| 	`code_ptr`	 | 		 |
| 	`align`	 | 	`bool `	 |

#### Depends on
* [`SysreqD`](#SysreqD)
#### Estimated stack usage
5 cells

